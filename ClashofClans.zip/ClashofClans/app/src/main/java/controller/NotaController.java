package controller;
import java.util.ArrayList;

import model.Nota;

public class NotaController {

    public NotaController(){

    }
    public boolean cadastrarNota(Nota nota){

        return false;
    }
    public Nota getNota(Integer id){
        return null;

    }
    public ArrayList<Nota> getListaNota(){
        return null;

    }
    public boolean excluirNota(Integer){
        return false;

    }
}
