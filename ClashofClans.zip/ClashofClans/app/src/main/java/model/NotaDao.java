package model;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class NotaDao {
    SQLiteDatabase sqLiteDataBase;

    public NotaDao(Context c){
        this.sqLiteDataBase = c.openOrCreateDatabase("bNotas", Context.MODE_PRIVATE, null);
        sqLiteDataBase.execSQL("CREATE TABLE notas (id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "titulo varchar," +
                "texto varchar)");
    }

    public Nota insertNota(Nota n){
        ContentValues contentValues=new ContentValues();
        contentValues.put("titulo", n.getTitulo());
        contentValues.put("texto", n.getTexto());
        sqLiteDataBase.insert("notas", null, contentValues);

        return n;
    }

    public boolean update (){
        return false;
    }

    public boolean delete (){
        return false;
    }

    public boolean search (){
        return false;
    }

    public ArrayList<Nota> getAll (){
        return null;
    }

    public boolean getNota (Long id){
        return false;
    }
}
