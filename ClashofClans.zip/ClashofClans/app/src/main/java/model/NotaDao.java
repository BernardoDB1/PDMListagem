package model;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class NotaDao {
    SQLiteDatabase sqLiteDataBase;

    public NotaDao(SQLiteDatabase sqLiteDataBase){
        this.sqLiteDataBase = c.openOrCreadeDatabase("b", Context.MODE_PRIVATE, null);
    }

    public boolean insert(Nota n){
        ContentValues contentValues=new ContentValues();
        contentValues.put("titulo", n.titulo);
        contentValues.put("txt", n.titulo);
        sqLiteDataBase.insert("notas", null, contentValues);
    }

    update

    delete

    getAll

}
